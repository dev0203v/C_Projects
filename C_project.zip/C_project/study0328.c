// 포인터 문제 풀기
/* 포인터로 최댓값과 최솟값 가리키기

int 포인터 변수 max와 min은 각각 int 변수 num1, num2
가리키고 있다 MaxMin 함수를 실행한 후에는 포인터
변수 max는 num1과 num2 중 최댓값을 가리키고
min은 최솟값을 가리킬 수 있도록 MaxMin 함수를 작성해라 */
// #include <stdio.h>
// void MaxMin(int*,int*);
// int main()
// {

//     int num1 = 3;
//     int num2 = 4;

//     int* max = &num1;
//     int* min = &num2;

//     MaxMin(&max,&min);

//     printf("max: %d\n",*max);
//     printf("min: %d\n",*min);

//     return 0;
// }

// void MaxMin(int* max, int* min)
// {
//     int temp = 0;
//     if(*max < *min){
//         temp = *min;
//         *min = *max;
//         *max = temp;
//     }
// }
/* 참고사항 
    num1과 num2의 값이 서로 교환되는 것이 아니라, max가 num2를 가리키고
    min이 num1을 가리켜야 한다.
    1.실매개변수로 max와 min의 주소가 전달되어야 한다.
    2.이에 따라 형식매개변수 역시 이중 포인터(int**)로 받아야 한다. */

// void MaxMin(int** max, int** min)
// {
//     int**a = int*min;
//     int**b = int*max;
//     // 어려워어어엉 어려우어어어어엉
// }    

/* 2.포인터로 최댓값 가리키기

int 1차원 배열 ary와 int* 변수 max가 있다.
pointMax 함수를 실행시키고 난 후에는 int* 변수가 1차원 배열의
요소들 중 최댓값이 있는 요소를 가리키도록 PointMax함수를 만들어라 */

// #include <stdio.h>
// void PointMax(int);
// int main()
// {
//     int ary[5] = {1,6,3,9,4};
//     int* max = NULL;

//     PointMax(*ary);

//     printf("max: %d\n",*max);

//     return 0;
// }
// void PointMax(int ary[])
// {   
//     int i;
//     int **max = 0;
//     for (i=0; ary[i]<=(sizeof(ary)/sizeof(int)); i++){
//         if(*max<&ary[i])
//             **max = ary[i];
//     }
// }

/* 3.평균 점수 계산하기

학생 1명의 점수는 국어, 수하그 영어가 있으며 여러명의 점수는
1차원 배열로 표현된다. 예를 들면 학생 5명의 점수는 5행3열의
2차원 배열이 된다. 학생들의 국어 평균, 수학 평균, 영어 평균은
3개의 요소로 이루어진 double 1차원 배열에 저장하려고 한다.
이와 같이 동작하도록 CalcAvg 함수를 작성하라 */

// #include <stdio.h>
// int CalcAvg(int,int,double)
// int main ()
// {
//     int score[5][3] = { {100, 90, 80},
//                         {60,70,85},
//                         {76, 79, 70},
//                         {100,100,95},
//                         {85,80,90}};

//     double average[3];
//     CalcAvg(score, 5, average);

//     printf("국어 평균 : %f\n",average[0]);
//     printf("수학 평균 : %f\n",average[1]);
//     printf("영어 평균 : %f\n",average[2]);

//     return 0;
// }
// int CalcAvg(int score,int 5,double average)
// {
//  뭐쓰지 .....?
//     return average;
// }

// void SimpleFunc(void)
// {
//     static int num1 = 0;
//     int num2 = 0;
//     num1++, num2++;
//     printf("ststic: %d, local: %d \n",num1,num2);
// }
// int main(void)
// {
//     int i;
//     for (i=0; i<3; i++)
//         SimpleFunc();
//     return 0;
// }


// #include <stdio.h>
// #include <stdlib.h>

// int main(void)
// {
//     int *ptr1 = (int *)malloc(sizeof(int));
//     int *ptr2 = (int *)malloc(sizeof(int)*7);
//     int i;

//     *ptr1 = 10;
//     for ( i = 0; i < 7; i++)
//         ptr2[i] = i+1;

//     printf("%d \n", *ptr1);
//     for ( i = 0; i < 7; i++)
//         printf("%d ",ptr2[i]);

//     free(ptr1);
//     free(ptr2);
//     return 0;   
// }

// #include <stdio.h>
// #include <stdlib.h>

// char * ReadUserName(void)
// {
//     char *name = (char *)malloc(sizeof(char)*30);
//     printf("What's your name? ");
//     fgets(name,30,stdin);
//     return name;
// }
// int main(void)
// {
//     char *name1;
//     char *name2;
//     name1 = ReadUserName();
//     printf("name1: %s \n",name1);
//     name2 = ReadUserName();
//     printf("name2: %s \n",name2);

//     printf("again name1: %s \n",name1);
//     printf("again name2: %s \n",name2);
//     free(name1);
//     free(name2);

//     return 0;
// }

// where.c -- where's the memory?

// #include <stdio.h>
// #include <stdlib.h>
// #include <string.h>

// int static_store = 30;
// const char *pcg = "String Literal";
// int main()
// {
//     int auto_store = 40;
//     char auto_string[] = "Auto char Array";
//     int *pi;
//     char *pcl;

//     pi = (int*) malloc(sizeof(int));
//     *pi = 35;
//     pcl = (char *)malloc(strlen("Dynamic String") + 1);
//     strcpy(pcl, "Dynamic String");

//     printf("static_store: %d at %p\n",static_store,&static_store);
//     printf("  auto_store: %d at %p\n",auto_store,&auto_store);
//     printf("         *pi: %d at %p\n",*pi,pi);
//     printf("  %s at %p\n",pcg,pcg);
//     printf(" %s at %p\n",auto_string,auto_string);
//     printf("  %s at %p\n",pcl,pcl);
//     printf("   %s at %p\n","Quoted String","Quoted String");
//     free(pi);
//     free(pcl);

//     return 0;
// }

// /* 문제01 "i am a boy"가 입력되면 
// "boy a am i"가 출력되도록 해야한다 */ 언젠간 풀겠지....
// #include <stdio.h>
// #include <stdlib.h>
// #include <string.h>
// int main()
// {
//     int i;
//     char temp[10];
//     char *string = (char *)malloc(sizeof(char)*10);
//     printf("문자열을 입력하시오 : ");
//     fgets(string,10,stdin);
    
//     // for(i=0; i<10; i++)
//     // {
//     //     temp[i] = string[9-i];
//     //     string[i] = temp[i];
//     //     printf("%s ",string[i]);
//     // }
//     printf("%s",string)

//     return 0;

// }

// //void 포인터
// #include <stdio.h>
// int main()
// {
//     int a = 10;                 // int형 변수
//     double b = 3.5;             // double형 변수
//     void *vp;                   // void 포인터

//     vp = &a;                // int형 변수의 주소 저장
//     printf("a : %d\n", *(int *)vp);
    
//     vp = &b;                // double형 변수의 주소 저장
//     printf("a : %.1f\n", *(double *)vp);

//     return 0;
// }

// //메모리의 사용
// #include <stdio.h>
// #include <stdlib.h>
// int main()
// {
//     int *pi;
//     int i, sum = 0;

//     pi = (int *)malloc(5 * sizeof(int));
//     if(pi == NULL)
//     {
//         printf("메모리가 부족합니다\n");
//         exit(1);
//     }
//     printf("다섯 명의 나이를 입력하세요 : ");
//     for ( i = 0; i < 5; i++)
//     {
//         scanf("%d",&pi[i]);
//         sum += pi[i];
//     }
//     printf("다섯 명의 평균 나이 : %.1f\n",(sum/5.0));
//     free(pi);
    
//     return 0;
// }

// #include <stdio.h>
// #include <stdlib.h>

// void InputScores(int *base,int asize); //asize 명의 성적을 입력받는 함수
// void ViewScores(int *base,int asize); //asize 명의 성적을 출력하는 함수
// int InputScore(int num); //num 번의 학생 성적을 입력받는 함수

// int main()
// {
//     int *base = 0;  //동적으로 할당받아 학생들의 성적을 관리할 메모리의 시작 주소
//     int max_stu= 0;   //관리할 학생 수
//     printf("최대 관리할 학생 수를 입력하세요.\n");
//     scanf("%d",&max_stu);
//     base = (int *)malloc(sizeof(int) * max_stu); //성적을 보관할 메모리를 할당
//     InputScores(base,max_stu); //학생들의 성적 입력 요청
//     ViewScores(base,max_stu); //학생들의 성적 출력
//     free(base); //동적으로 할당한 메모리 해제
//     return 0;
// }
// void InputScores(int *base,int asize)
// {
//     int i = 0;
//     for(i = 0;  i<asize; i++)
//     {
//         base[i] = InputScore(i+1); //i+1 번의 학생 성적을 입력받아 base[i]에 대입
//     }
// }
// void ViewScores(int *base,int asize)
// {
//     int i = 0;
//     for ( i = 0; i < asize; i++)
//     {
//         printf("%d 번: %d 점\n",i+1,base[i]);
//     }
// }
// int InputScore(int num)
// {
//     int score;
//     printf("%d 번의 성적을 입력하세요.\n",num);
//     scanf("%d",&score);

//     return score;
// }

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int *pi;
    int size = 5;
    int cnt = 0;
    int num;
    int i;

    pi = (int*)calloc(size,sizeof(int)); // 먼저 5개의 저장 공간 할당
    while(1)
    {
        printf("양수를 입력하세요 -> ");
        scanf("%d",&num);
        if(num <= 0) break;
        if(cnt < size)
        {
            pi[cnt++] = num;
        }
        else
        {
            size += 5;
            pi = (int *)realloc(pi, sizeof(int));
            pi[cnt++] = num;
        }
    }
    for ( i = 0; i < cnt; i++)
    {
        printf("%5d",pi[i]);
    }
    free(pi);

    return 0;
}